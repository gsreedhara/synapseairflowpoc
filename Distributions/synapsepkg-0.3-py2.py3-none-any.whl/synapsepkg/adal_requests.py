import adal
import os


def __init__(self, params) -> None:
    pass
def getbearertoken(resource, env_file=None):
    tenant = os.environ['TENANT']
    authority_url = 'https://login.microsoftonline.com/' + tenant
    client_id = os.environ['CLIENTID']
    client_secret = os.environ['CLIENTSECRET']
    resource = resource
    context = adal.AuthenticationContext(authority_url)
    token = context.acquire_token_with_client_credentials(resource, client_id, client_secret)
    return token
