# -------------------------------------------------------------------#
# - Created By: Giridhar Sreedhara
# - Date Initial Version : 08/20/2023
# - Description:
# - These methods are created as a mode to authenticate make API requestse to
# - The Azure Synapse service. This functionality is currently not available in the
# - market
# -------------------------------------------------------------------
import sys
import requests
import adal
import os


def getbearertoken(resource, tenantid, clientid, clientsecret):
    # tenant = os.environ['TENANT']
    tenant = tenantid
    authority_url = 'https://login.microsoftonline.com/' + tenant
    # client_id = os.environ['CLIENTID']
    client_id = clientid
    # client_secret = os.environ['CLIENTSECRET']
    client_secret = clientsecret
    resource = resource
    context = adal.AuthenticationContext(authority_url)
    try:
        token = context.acquire_token_with_client_credentials(resource, client_id, client_secret)
        return token
    except:
        print("Error: Failed to authenticate token with provided credentials")


def createrun(endpoint, pipelineName, tenantid, clientid, clientsecret):
    """desc: This will do an API PUSH req to start a pipeline run.
       The return code will be the RUNID that you can use to check the status subsequently.
       Error handling needs to be implemented- Basic error handling implemented for the time being
    """
    tenantid = tenantid
    clientid = clientid
    clientsecret = clientsecret
    resource = 'https://dev.azuresynapse.net/'
    # first authenticate by getting the bearer token
    token = getbearertoken(resource, tenantid, clientid, clientsecret)
    headers = {'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    params = {'api-version': '2020-12-01'}
    url = f'https://{endpoint}.dev.azuresynapse.net/pipelines/{pipelineName}/createRun'
    val = ''
    try:
        r = requests.post(url, headers=headers, params=params)
        r.raise_for_status()
        for key, value in r.json().items():
            if key == 'runId':
                val = value
        # print("the value is:", val)
        return val
    except requests.exceptions.HTTPError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.ConnectionError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.Timeout as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"


def getpipelinerun(endpoint, runID, tenantid, clientid, clientsecret):
    """desc: This will do an API PULL/GET req to get status of a pipeline run.
          The return code will be the pipeline status - IN progress or Succeeded
          that you can use update status and close the job.
          Error handling needs to be implemented- Basic error handling implemented for the time being
       """
    tenantid = tenantid
    clientid = clientid
    clientsecret = clientsecret
    resource = 'https://dev.azuresynapse.net/'
    # first authenticate by getting the bearer token
    token = getbearertoken(resource, tenantid, clientid, clientsecret)
    headers = {'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    params = {'api-version': '2020-12-01'}

    url = f'https://{endpoint}.dev.azuresynapse.net/pipelineruns/{runID}'
    try:
        r = requests.get(url, headers=headers, params=params)
        r.raise_for_status()
        val = ''
        for key, value in r.json().items():
            # print(key, value)
            if key == 'status':
                val = value
        print("the value is:", val)
        return val
    except requests.exceptions.HTTPError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.ConnectionError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.Timeout as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"

def deletePipeline(endpoint, pipelineName, tenantid, clientid, clientsecret):
    """desc: This will do an API POST req to delete a pipeline.
          The return code will be the pipeline status - 200 for Success/OK
                                                        202 for accepted
                                                        204 No content
                                                        other codes for Errors
        Error handling needs to be implemented- Basic error handling implemented for the time being
       """
    tenantid = tenantid
    clientid = clientid
    clientsecret = clientsecret
    resource = 'https://dev.azuresynapse.net/'
    # first authenticate by getting the bearer token
    token = getbearertoken(resource, tenantid, clientid, clientsecret)
    headers = {'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    params = {'api-version': '2020-12-01'}

    url = f'https://{endpoint}.dev.azuresynapse.net/pipelines/{pipelineName}'
    try:
        r = requests.get(url, headers=headers, params=params)
        r.raise_for_status()
        val = ''
        for key, value in r.json().items():
            # print(key, value)
            if key == 'status':
                val = value
        print("the value is:", val)
        return val
    except requests.exceptions.HTTPError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.ConnectionError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.Timeout as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"

def getPipelineByWorkspace(endpoint, tenantid, clientid, clientsecret):
    """desc: This will do an API GET req to get properties of all pipeline runs under a workspace.
          The return code will be the pipeline status - 200 for Success/OK with pipeline list
                                                        other codes for Errors
          Error handling needs to be implemented- Basic error handling implemented
          Response will be a JSON with complete list of pipelines, activities and their corresponding properties
       """
    tenantid = tenantid
    clientid = clientid
    clientsecret = clientsecret
    resource = 'https://dev.azuresynapse.net/'
    # first authenticate by getting the bearer token
    token = getbearertoken(resource, tenantid, clientid, clientsecret)
    headers = {'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    params = {'api-version': '2020-12-01'}

    url = f'https://{endpoint}.dev.azuresynapse.net/pipelines'
    try:
        r = requests.get(url, headers=headers, params=params)
        r.raise_for_status()
        val = ''
        for key, value in r.json().items():
            # print(key, value)
            if key == 'status':
                val = value
        print("the value is:", val)
        return val
    except requests.exceptions.HTTPError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.ConnectionError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.Timeout as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"

def queryActivityRuns(endpoint, pipelineName, runId, tenantid, clientid, clientsecret):
    """desc: This will do an API POST req to get statuses of all pipeline runs under a workspace.
          The return code will be the pipeline status - 200 for Success/OK with JSON of activity run statuses
                                                        other codes for Errors
          Error handling needs to be implemented - Basic error handling implemented
          Response will be a JSON with complete list of pipeline-activities and their corresponding Statuses
          Filters to be added as arguments sent to the request needs to  be added. this will fine tune specific filter
          we want to query for
       """
    tenantid = tenantid
    clientid = clientid
    clientsecret = clientsecret
    resource = 'https://dev.azuresynapse.net/'
    # first authenticate by getting the bearer token
    token = getbearertoken(resource, tenantid, clientid, clientsecret)
    headers = {'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    params = {'api-version': '2020-12-01'}

    url = f'https://{endpoint}.dev.azuresynapse.net/pipelines/{pipelineName}/pipelineruns/{runId}/queryActivityruns'
    try:
        r = requests.get(url, headers=headers, params=params)
        r.raise_for_status()
        val = ''
        for key, value in r.json().items():
            # print(key, value)
            if key == 'status':
                val = value
        print("the value is:", val)
        return val
    except requests.exceptions.HTTPError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.ConnectionError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.Timeout as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"

def queryPipelineRunsByWorkspace(endpoint, tenantid, clientid, clientsecret):
    """desc: This will do an API POST req to get statuses of all pipeline runs under a workspace.
          The return code will be the pipeline status - 200 for Success/OK with JSON of activity run statuses
                                                        other codes for Errors
          Error handling needs to be implemented - Basic error handling implemented
          Response will be a JSON with complete list of pipeline-activities and their corresponding Statuses
          Filters to be added as arguments sent to the request needs to  be added. this will fine tune specific filter
          we want to query for.
          For example, the below
          PARAMS TO THE POST REQ:
          {
          "lastUpdatedAfter": "2018-06-16T00:36:44.3345758Z",
          "lastUpdatedBefore": "2018-06-16T00:49:48.3686473Z",
          "filters": [
            {
              "operand": "PipelineName",
              "operator": "Equals",
              "values": [
                "examplePipeline"
              ]
            }
          ]
        }
       """
    tenantid = tenantid
    clientid = clientid
    clientsecret = clientsecret
    resource = 'https://dev.azuresynapse.net/'
    # first authenticate by getting the bearer token
    token = getbearertoken(resource, tenantid, clientid, clientsecret)
    headers = {'Authorization': 'Bearer ' + token['accessToken'], 'Content-Type': 'application/json'}
    params = {'api-version': '2020-12-01'}

    url = f'https://{endpoint}.dev.azuresynapse.net/queryPipelineRuns'
    try:
        r = requests.get(url, headers=headers, params=params)
        r.raise_for_status()
        val = ''
        for key, value in r.json().items():
            # print(key, value)
            if key == 'status':
                val = value
        print("the value is:", val)
        return val
    except requests.exceptions.HTTPError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.ConnectionError as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
    except requests.exceptions.Timeout as e:
        print("Error ".center(80, "-"))
        print(e, file=sys.stderr)
        return "Error"
